Rachitrali-Munji Keyboard Data
-------------------------------

Copyright:      (C) 2020 Rehmat Aziz Chitrali
Version:        1.0

Description
-----------

This keyboard is designed for the Munji language spoken in the Afghanistan and Pakistan, in its standard Perso-Arabic script, as used in Afghanistan and Pakistan. It is based on phonetic keyboard for Munji Language developed by Pakistani linguist, author, researcher, Inventor, Scientist and Software Developer Mr.Rehmat Aziz Chitrali for Khowar Academy(an literary Association working on the language and culture documentation in Northern Pakistan) used in Windows 8.1 and above as Munji Keyboard.

This is the first Munji language keyboard created by Rehmat Aziz Chitrali, Pakistani linguist, author, researcher, Inventor, Scientist and Software Developer. This keyboard is for Munji Language based on the keyboard layout as developed by Mr.Rehmat Aziz Chitrali and approved by Khowar Academy of Pakistan as standard keyboard for Munji language.

The Munji Keyboard Project(MKP) was supervised and developed by Rehmat Aziz Chitrali, who heads the Khowar Academy Chitral Pakistan.

Khowar Academy Chitral was established in April 1996 specifically to promote the endangered languages of Chitral Pakistan. The Academy has worked extensively on Munji linguistics, standardization for computing, and modeling of script, speech and language. Research is being conducted in all aspects of Munji, including acoustic phonetics, phonology, morphology, syntax, grammar and semantics.

Links
-----


 * Home:    https://keymanweb.com/#mnj-Arab,Keyboard_rac_munji
 * Help:    https://help.keyman.com/keyboard/rac_munji
 * Contact: Rehmat Aziz Chitrali linguist and researcher <rachitrali@yahoo.com>

Supported Platforms
-------------------
 * Windows
 * Web
 * macOS
 * iOS
 * Android
 * Linux