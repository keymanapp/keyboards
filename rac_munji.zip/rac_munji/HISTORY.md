Rachitrali-Munji Change History
================================

1.0 (25 April 2020)
-----------------
* Created by Rehmat Aziz Chitrali Linguist and Researcher at Khowar Academy Chitral Khyber Pakhtunkhwa Pakistan