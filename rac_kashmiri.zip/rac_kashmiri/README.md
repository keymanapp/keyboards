Rachitrali-Kashmiri Keyboard Data
-------------------------------

Copyright:      (C) 2020 Rehmat Aziz Chitrali
Version:        1.0

Description
-----------

This keyboard is designed for the Kashmiri language spoken in the Kashmir, India and Pakistan, in its standard Perso-Arabic script, as used in Kashmir, India and Pakistan. It is based on phonetic keyboard for Kashmiri Language developed by Pakistani linguist, author, researcher, Inventor, Scientist and Software Developer Mr.Rehmat Aziz Chitrali for Khowar Academy(an literary Association working on the language and culture documentation in Northern Pakistan) used in Windows 8.1 and above as Kashmiri Keyboard.

This is the first Kashmiri language keyboard created by Rehmat Aziz Chitrali, Pakistani linguist, author, researcher, Inventor, Scientist and Software Developer. This keyboard is for Kashmiri Language based on the keyboard layout as developed by Mr.Rehmat Aziz Chitrali and approved by Khowar Academy of Pakistan as standard keyboard for Kashmiri language.

The Kashmiri Keyboard Project(KKP) was supervised and developed by Rehmat Aziz Chitrali, who heads the Khowar Academy Chitral Pakistan.

Khowar Academy Chitral was established in April 1996 specifically to promote the endangered languages of Chitral Pakistan. The Academy has worked extensively on Kashmiri linguistics, standardization for computing, and modeling of script, speech and language. Research is being conducted in all aspects of Kashmiri, including acoustic phonetics, phonology, morphology, syntax, grammar and semantics.

Links
-----


 * Home:    https://keymanweb.com/#ks-Arab,Keyboard_rac_kashmiri
 * Help:    https://help.keyman.com/keyboard/rac_kashmiri
 * Contact: Rehmat Aziz Chitrali linguist and researcher <rachitrali@yahoo.com>

Supported Platforms
-------------------
 * Windows
 * Web
 * macOS
 * iOS
 * Android
 * Linux