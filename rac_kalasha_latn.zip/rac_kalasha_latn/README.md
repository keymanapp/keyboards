Rachitrali-Kalasha_Latn Keyboard Data
-------------------------------

Copyright:      (C) 2020 Rehmat Aziz Chitrali
Version:        1.0

Description
-----------

This keyboard is designed for the Kalasha language spoken in Rumbur, Birir and Bumburet of Kalash Valleys, Chitral, Khyber Pakhtunkhwa Province  of Pakistan, in its standard Perso-Arabic script, as used in Pakistan. It is based on phonetic keyboard for Kalasha Language developed by Pakistani linguist, author, researcher, Inventor, Scientist and Software Developer Mr.Rehmat Aziz Chitrali for Khowar Academy(an literary Association working on the language and culture documentation in Northern Pakistan) used in Windows 8.1 and above as Kalasha Keyboard.

This is the first Kalasha language keyboard created by Rehmat Aziz Chitrali, Pakistani linguist, author, researcher, Inventor, Scientist and Software Developer. This keyboard is for Kalasha Language based on the keyboard layout as developed by Mr.Rehmat Aziz Chitrali and approved by Khowar Academy of Pakistan as standard keyboard for Kalasha language.

The Kalasha Keyboard Project(KKP) was supervised and developed by Rehmat Aziz Chitrali, who heads the Khowar Academy Chitral Pakistan.

Khowar Academy Chitral was established in April 1996 specifically to promote the endangered languages of Chitral Pakistan. The Academy has worked extensively on Kalasha linguistics, standardization for computing, and modeling of script, speech and language. Research is being conducted in all aspects of Kalasha, including acoustic phonetics, phonology, morphology, syntax, grammar and semantics.

Links
-----


 * Home:    https://keymanweb.com/#kls-Latn,Keyboard_rac_kalasha_latn
 * Help:    https://help.keyman.com/keyboard/rac_kalasha_latn
 * Contact: Rehmat Aziz Chitrali linguist and researcher <rachitrali@yahoo.com>

Supported Platforms
-------------------
 * Windows
 * Web
 * macOS
 * iOS
 * Android
 * Linux