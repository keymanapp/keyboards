Xinaliq Keyboard Change History
=======================

1.0 (22 March 2019)
-----------------

* Initial release
