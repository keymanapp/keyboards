Xinaliq Keyboard
=====================

Copyright (C) 2019 Kenneth Keyes
Version 1.0

__DESCRIPTION__
Keyboard for Xinaliq (kjj) using the Latin Orthography approved by the Ministry of Education of the Republic of Azerbaijan.

Links
-----

 * Contact:  ken_keyes@sil.org

Supported Platforms
-------------------
 * Windows
 * macOS
 * Web
 * Mobile Web
 * iOS
 * Android
 * Linux


  
  


 