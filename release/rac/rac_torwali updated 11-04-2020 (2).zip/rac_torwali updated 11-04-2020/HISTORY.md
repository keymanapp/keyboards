Rachitrali-Torwali Change History
================================

1.0 (11 April 2020)
-----------------
* Created by Rehmat Aziz Chitrali Linguist and Researcher at Khowar Academy Chitral Khyber Pakhtunkhwa Pakistan