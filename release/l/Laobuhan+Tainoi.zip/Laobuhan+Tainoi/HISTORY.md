Laobuhan + TaiNoi (Unicode) Change History
====================

1.0 (2025-07-25)
----------------
* Created by Jayasāro Bhikkhu
